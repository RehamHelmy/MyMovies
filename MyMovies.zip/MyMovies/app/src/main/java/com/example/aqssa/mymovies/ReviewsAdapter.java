package com.example.aqssa.mymovies;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by Aqssa on 28/04/2016.
 */
public class ReviewsAdapter extends ArrayAdapter<String> {
    private Activity context;
    private int LayoutResourse;
    private ArrayList<String> Reviews_List;
    private ArrayList<String> Reviewers_Names;
    LayoutInflater inflater;



    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view;
        view = convertView;
        ViewHolder holder;
        if (view==null){
            view = inflater.inflate(LayoutResourse,null);
            holder = new ViewHolder(view);
            view.setTag(holder);
        }else {
            holder= (ViewHolder) view.getTag();
        }
        holder.name.setText(Reviewers_Names.get(position));
        holder.review.setText(Reviews_List.get(position));

        return view;
    }

    public ReviewsAdapter(Context context, ArrayList NamesList, ArrayList ContentList, int Resourse) {
        super(context,Resourse,ContentList);
        Reviews_List= ContentList;
        Reviewers_Names=NamesList;
        LayoutResourse = Resourse;
        inflater= LayoutInflater.from(context);
    }
    public class ViewHolder{
        public TextView name;
        public TextView review;
        public ViewHolder(View view){
            name = (TextView) view.findViewById(R.id.reviewerName);
            review = (TextView)view.findViewById(R.id.review_item);
        }

    }

}

