package com.example.aqssa.mymovies;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by Aqssa on 28/04/2016.
 */
public class GridImageAdapter extends ArrayAdapter {

    private Context mContext;
    private int imageType;
    private ArrayList<String> mGridData = new ArrayList<>();
    private ArrayList<String> mGridData_from_Database = new ArrayList<>();

    private LayoutInflater inflater;



    public GridImageAdapter(Context Context, ArrayList<String> gridData) {
        super(Context, 0, gridData);

        mContext = Context;
        mGridData = gridData;

        inflater = LayoutInflater.from(mContext);
    }

    public GridImageAdapter(Context context) {
        super(context, 0);
    }

    @Override
    public int getPosition(Object item) {
        return super.getPosition(item);
    }




    public void setGridData(ArrayList mGridData, int imageType) {
        this.mGridData = mGridData;
        this.imageType = imageType; // =1 for online data
        notifyDataSetChanged();
    }

    public void setGridDataFromDatabase(ArrayList<String> mGridData, int imageType) {
        mGridData_from_Database = mGridData;
        this.imageType = imageType; // = 2 for data from database
        notifyDataSetChanged();
    }


    public int getCount() {
        if (imageType == 1) {
            return mGridData.size();
        } else {
            return mGridData_from_Database.size();
        }

    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row = convertView;
        ViewHolder holder;

        if (row == null) {
            //     LayoutInflater inflater = ((Context) mContext).getLayoutInflater();
            row = inflater.inflate(R.layout.gridview_item, parent, false);
            holder = new ViewHolder();
            holder.imageView = (ImageView) row.findViewById(R.id.imageViewww);
            row.setTag(holder);
        } else {
            holder = (ViewHolder) row.getTag();
        }


        if (imageType == 1) {
            Picasso.with(mContext)
                    .load(mGridData.get(position))
                    .into(holder.imageView);
        } else {

            Picasso.with(mContext)
                    .load(mGridData_from_Database.get(position))
                    .into(holder.imageView);

        }

        return row;
    }

    static class ViewHolder {
        public ImageView imageView;
    }


}
