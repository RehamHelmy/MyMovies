package com.example.aqssa.mymovies;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.widget.ShareActionProvider;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by Aqssa on 28/04/2016.
 */
public class DetailFragment extends Fragment {


    private String trailerJSON_URL;
    private String reviewsJSON_URL;
    private ShareActionProvider mShareActionProvider;
    private ImageView posterImage;
    private TextView title;
    private TextView overview;
    private TextView releaseDate;
    private TextView ratingRatio;
    private RatingBar ratingBar;
    private TextView reviewsHeader;
    private FrameLayout frameDivider;
    private ImageView addedConfirmation;
    private Listview trailersList;
    private Listview reviewsList;
    private ImageView addToFavorites;
    private TextView trailersHeader;

    private static String id;
    private static int source;
     private static boolean starred;
    private static boolean isEmptyFragment;
    private static Context context;
    private static String posterUrl;
    private static String titleFromIntent;
    private static String overviewFromIntent;
    private static String releaseDateFromIntent;
    private static String ratingFromIntent;

    private final  String MOVIE_ID = "id";
    private final String MOVIE_SOURCE = "Source";
    private final String MOVIE_POSTER="poster";
    private final  String MOVIE_TITLE= "title";
    private final  String MOVIE_OVERVIEW= "overview";
    private final  String MOVIE_RELEASE_DATE= "release_date";
    private final  String MOVIE_RATING= "rating";




    ArrayList<String> reviewersNamesList = new ArrayList<>();
    ArrayList<String> reviewsContentList = new ArrayList<>();
    ArrayList<String> trailersYoutubeList =new ArrayList<>();

    public DetailFragment() {
    }

    public DetailFragment(Context context) {
        this.context = context;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_share, menu);

        MenuItem menuItem = menu.findItem(R.id.action_share);
        mShareActionProvider = (ShareActionProvider) MenuItemCompat.getActionProvider(menuItem);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_detail, container, false);

        posterImage = (ImageView) rootView.findViewById(R.id.poster);
        title = (TextView) rootView.findViewById(R.id.Detail_TextView_Title);
        overview = (TextView) rootView.findViewById(R.id.overview);
        releaseDate = (TextView) rootView.findViewById(R.id.release_date);
        ratingRatio = (TextView) rootView.findViewById(R.id.RatingRtio);
        ratingBar = (RatingBar) rootView.findViewById(R.id.ratingBar);
        trailersList = (Listview) rootView.findViewById(R.id.trailer_list);
        reviewsList = (Listview)rootView.findViewById(R.id.ReviewsList);
        addToFavorites = (ImageView) rootView.findViewById(R.id.emptyStar);
        trailersHeader = (TextView) rootView.findViewById(R.id.TrailersHeader);
        reviewsHeader = (TextView) rootView.findViewById(R.id.ReviewsHeader);
        frameDivider = (FrameLayout) rootView.findViewById(R.id.AboveReviews);
        addedConfirmation = (ImageView) rootView.findViewById(R.id.added_confirmation);


        ratingBar.setFocusable(false);
        trailersList.setExpanded(true);
        reviewsList.setExpanded(true);


        Bundle arguments = getArguments();

        if (arguments != null) {
            id =arguments.getString(MOVIE_ID);
            posterUrl =arguments.getString(MOVIE_POSTER);
            titleFromIntent = arguments.getString(MOVIE_TITLE);
            overviewFromIntent = arguments.getString(MOVIE_OVERVIEW);
            releaseDateFromIntent = arguments.getString(MOVIE_RELEASE_DATE);
            ratingFromIntent = arguments.getString(MOVIE_RATING);
            source = arguments.getInt(MOVIE_SOURCE);

            if (CheckRepetition(id)){
                addToFavorites.setImageResource(R.drawable.ic_fullstar);
                addedConfirmation.setVisibility(View.VISIBLE);
            }

            Picasso.with(getActivity())
                    .load(posterUrl)
                    .into(posterImage);


            addToFavorites.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View view) {

                    if (!starred) {
                        addMovie();
                        addToFavorites.setImageResource(R.drawable.ic_fullstar);
                        addedConfirmation.setVisibility(View.VISIBLE);
                    } else {
                        deleteMovie(id);
                        addedConfirmation.setVisibility(View.GONE);
                        addToFavorites.setImageResource(R.drawable.ic_emptystar);
                    }
                    starred = !starred;
                }

            });


            title.setText(titleFromIntent);
            overview.setText(overviewFromIntent);
            releaseDate.setText(releaseDateFromIntent);
            ratingBar.setRating(Float.parseFloat(ratingFromIntent));
            ratingRatio.setText(ratingFromIntent + " /10");


            trailerJSON_URL = "http://api.themoviedb.org/3/movie/"+ id +"/videos?api_key="+MainActivity.API_KEY;
            reviewsJSON_URL = "http://api.themoviedb.org/3/movie/"+ id +"/reviews?api_key="+MainActivity.API_KEY;


            ratingBar.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    return true;
                }
            });

            isEmptyFragment=false;

        }else {
            isEmptyFragment=true;
            rootView= inflater.inflate(R.layout.activity_detail,container,false);
        }

        return rootView ;
    }





    @Override
    public void onResume() {
        super.onResume();

        trailersList.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int position, long arg3) {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(trailersYoutubeList.get(position)));
                i = Intent.createChooser(i, "Choose your preferred App");
                if (i.resolveActivity(getActivity().getPackageManager()) != null) {
                    startActivity(i);
                } else {
                    Toast.makeText(getActivity(), "Couldn't find it", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private Intent createShareFirstTrailer() {
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET);
        shareIntent.setType("text/plain");
        shareIntent.putExtra(Intent.EXTRA_TEXT, trailersYoutubeList.get(0)); // this is null
        return shareIntent;
    }


    @Override
    public void onStart() {
        super.onStart();


        if (!isEmptyFragment){

            if (GridFragment.mConnectivity){
                FetchTrailer fetchTrailer = new FetchTrailer();
                fetchTrailer.execute(trailerJSON_URL);
                FetchReviews fetchReviews = new FetchReviews();
                fetchReviews.execute(reviewsJSON_URL);
            }
            else
            {
                Toast.makeText(context,"Loading Movies Data ",Toast.LENGTH_LONG).show();

            }

        }



    }

    public boolean CheckRepetition (String id){

        boolean inDatabase= false;
        Cursor c = getActivity().getContentResolver().query(FavoritesProvider.CONTENT_URI, null, null, null, "name");
        if(c==null){
            Toast.makeText(getContext(),"No data",Toast.LENGTH_SHORT).show();
        }else {
            if (!c.moveToFirst()) {
            } else {
                String movie_id;
                do {
                    movie_id = c.getString(c.getColumnIndex(FavoritesProvider.MOVIE_ID_FROM_TMDB));
                    if (movie_id.equals(id)) {
                        inDatabase = true;
                    }
                } while (c.moveToNext());
            }
        }
        starred =inDatabase; // **** assign it from inside the method!! ****
        return inDatabase;

    }

    public void addMovie() { //  add to database

        ContentValues values = new ContentValues();

        values.put(FavoritesProvider.MOVIE_ID_FROM_TMDB,
                id);

        values.put(FavoritesProvider.MOVIE_NAME,
                titleFromIntent);

        values.put(FavoritesProvider.MOVIE_POSTER,
                posterUrl);

        values.put(FavoritesProvider.MOVIE_RELEASE_DATE,
                releaseDateFromIntent);

        values.put(FavoritesProvider.MOVIE_RATE,
                ratingFromIntent);

        values.put(FavoritesProvider.MOVIE_OVERVIEW,
                overviewFromIntent);

        getActivity().getContentResolver().insert(
                FavoritesProvider.CONTENT_URI, values);

        Toast.makeText(getActivity(),
                "Marked as favorite!", Toast.LENGTH_SHORT).show();
    }

    public void deleteMovie(String ID){

        ContentResolver cr = getActivity().getContentResolver();
        cr.delete(FavoritesProvider.CONTENT_URI.buildUpon().appendPath(ID).build(), null, null);
        Toast.makeText(getActivity(),
                "Unmarked", Toast.LENGTH_SHORT).show();

    }



    public class FetchTrailer extends AsyncTask<String,Void,String[]> {

        final String LOG_TAG_AsyncTsk = FetchTrailer.class.getSimpleName();


        @Override
        protected String[] doInBackground(String... params) {

            HttpURLConnection urlConnection = null;
            BufferedReader reader = null;
            String movieJsonStr_FOR_Trailer = null;

            try {

                URL url = new URL(params[0]);

                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.connect();

                InputStream inputStream = urlConnection.getInputStream();
                StringBuffer buffer = new StringBuffer();

                if (inputStream == null) {
                    return null;
                }

                reader = new BufferedReader(new InputStreamReader(inputStream));

                String line;
                while ((line = reader.readLine()) != null) {
                    buffer.append(line + "\n");
                }

                if (buffer.length() == 0) {
                    return null;
                }

                movieJsonStr_FOR_Trailer = buffer.toString();

            } catch (IOException e) {
                Log.e(LOG_TAG_AsyncTsk, "Error ", e);
                return null;
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (final IOException e) {
                        Log.e(LOG_TAG_AsyncTsk, "Error closing stream", e);
                    }
                }
            }

            try {
                return getMovieDataJSON(movieJsonStr_FOR_Trailer);
            } catch (JSONException e) {
                e.printStackTrace();
            }

            return null;
        }

        private String [] getMovieDataJSON (String TrailerStr) throws JSONException {

            final String YOUTUBE_BASE_URL = "https://www.youtube.com/watch?v=";
            final String RESULTS = "results";
            final String MOVIE_KEY ="key";

            String Youtube_Source;
            JSONObject Trailers = new JSONObject(TrailerStr);
            JSONArray TrailerArray = Trailers.getJSONArray(RESULTS);

            String[] TrailerURLs = new String[TrailerArray.length()];

            for (int i = 0; i < TrailerArray.length(); i++) {
                JSONObject ArrayElement = TrailerArray.getJSONObject(i);
                Youtube_Source = ArrayElement.getString(MOVIE_KEY);
                TrailerURLs[i] = YOUTUBE_BASE_URL+Youtube_Source;
            }

            return TrailerURLs;
        }

        @Override
        protected void onPostExecute(String[] strings) {
            super.onPostExecute(strings);

            trailersYoutubeList.clear();
            for (int i =0 ; i < strings.length; i++){
                trailersYoutubeList.add(strings[i]);
            }


            TrailerAdapter  Adapter = new TrailerAdapter(context,
                    trailersYoutubeList);
            trailersList.setAdapter(Adapter);

            if(trailersYoutubeList.size()<1){
                trailersHeader.setVisibility(View.GONE);
            }

            if (mShareActionProvider!=null && trailersYoutubeList.size()>=1 && GridFragment.mConnectivity) {
                mShareActionProvider.setShareIntent(createShareFirstTrailer());
            }

        }

    }

    public class FetchReviews extends AsyncTask<String,Void,String[][]>
    {
        final String LOG_TAG_AsyncTsk=FetchReviews.class.getSimpleName();

        @Override
        protected String[][] doInBackground(String... params) {
            HttpURLConnection urlConnection = null;
            BufferedReader reader = null;
            String movieJsonStr_FOR_Reviews = null;

            try {

                URL url = new URL(params[0]);

                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.connect();

                InputStream inputStream = urlConnection.getInputStream();
                StringBuffer buffer = new StringBuffer();

                if (inputStream == null) {
                    return null;
                }

                reader = new BufferedReader(new InputStreamReader(inputStream));

                String line;
                while ((line = reader.readLine()) != null) {
                    buffer.append(line + "\n");
                }

                if (buffer.length() == 0) {
                    return null;
                }

                movieJsonStr_FOR_Reviews = buffer.toString();

            } catch (IOException e) {
                Log.e(LOG_TAG_AsyncTsk, "Error ", e);
                return null;
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (final IOException e) {
                        Log.e(LOG_TAG_AsyncTsk, "Error closing stream", e);
                    }
                }
            }

            try {
                return getMovieDataJSON(movieJsonStr_FOR_Reviews);
            } catch (JSONException e) {
                e.printStackTrace();

            }

            return null;
        }



        private String [][] getMovieDataJSON (String ReviewsStr) throws JSONException {


            final String REVIEWS_ARRAY ="results";
            final String AUTOR ="author";
            final String AUTHOR_REVIEW ="content";

            String authorName ;
            String reviewContent;

            JSONObject Review = new JSONObject(ReviewsStr); // Reviews
            JSONArray Reviews_Array = Review.getJSONArray(REVIEWS_ARRAY);

            String[][] ReviewersAndReviews = new String[Reviews_Array.length()][2];

            for (int i = 0; i < Reviews_Array.length(); i++) {
                JSONObject ArrayElement = Reviews_Array.getJSONObject(i);
                authorName = ArrayElement.getString(AUTOR);
                ReviewersAndReviews[i][0]= authorName+" :";
            }

            for (int i = 0; i < Reviews_Array.length(); i++) {
                JSONObject ArrayElement = Reviews_Array.getJSONObject(i);
                reviewContent = ArrayElement.getString(AUTHOR_REVIEW);
                ReviewersAndReviews[i][1] = reviewContent;
            }


            return ReviewersAndReviews;
        }



        @Override
        protected void onPostExecute(String[][] strings) {
            super.onPostExecute(strings);

            reviewersNamesList.clear();
            reviewsContentList.clear();

            for (int i =0 ; i < strings.length; i++){
                reviewersNamesList.add(strings[i][0]);
            }
            for (int i =0 ; i < strings.length; i++){
                reviewsContentList.add(strings[i][1]);
            }

            ReviewsAdapter ReviewsAdapter = new com.example.aqssa.mymovies.ReviewsAdapter(context,reviewersNamesList, reviewsContentList,R.layout.reviews_listview_item);
            reviewsList.setAdapter(ReviewsAdapter);

            if(reviewsContentList.size()<1){
                reviewsHeader.setVisibility(View.GONE);
                frameDivider.setVisibility(View.GONE);
            }


        }
    }

}

