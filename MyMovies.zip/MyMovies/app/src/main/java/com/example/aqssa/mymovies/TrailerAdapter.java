package com.example.aqssa.mymovies;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by Aqssa on 28/04/2016.
 */
public class TrailerAdapter extends ArrayAdapter<String> {

    private Activity context;
    private ArrayList<String> URL_LIST;
    LayoutInflater inflater;
    int trailer_id;





    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view;
        view = convertView;
        ViewHolder holder;
        if (view==null){
            view = inflater.inflate(R.layout.trailer_listview,null);
            holder = new ViewHolder(view);
            view.setTag(holder);
        }else {
            holder= (ViewHolder) view.getTag();
        }

        trailer_id = position+1;
        holder.textView.setText("Trailer " + trailer_id);

        return view;
    }
    public TrailerAdapter(Context context, ArrayList URL_list) {
        super(context,0,URL_list);
        this.URL_LIST= URL_list;
        inflater= LayoutInflater.from(context);

    }

    public class ViewHolder{

        public TextView textView;

        public ViewHolder(View view){
            textView=(TextView)  view.findViewById(R.id.trailer_text_id);
        }

    }
}
