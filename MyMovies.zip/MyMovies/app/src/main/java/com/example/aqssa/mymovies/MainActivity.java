package com.example.aqssa.mymovies;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;


public class MainActivity extends ActionBarActivity implements GridFragment.Callback {


    public static final String API_KEY = "";

    private static final String DETAIL_FRAGMENT_TAG = "DFTAILTAG";
    public static boolean test;
    public static Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(R.color.darker_blue));

        context =getApplicationContext();

        if (findViewById(R.id.movie_detail_container) != null) {

            test = true;
            if (savedInstanceState == null) {
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.movie_detail_container, new DetailFragment(), DETAIL_FRAGMENT_TAG)
                        .commit();
            }
        } else {
            test = false;
        }


    }



    public static Context getContext(){
        return context;
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if (id == R.id.action_settings) {
            startActivity(new Intent(this,SettingsActivity.class));
            return true;
        }



        return super.onOptionsItemSelected(item);
    }


    @Override
    public void onItemSelected(Intent intent) {

        if (test) {
            Bundle args = new Bundle();
            args.putAll(intent.getExtras());
            DetailFragment fragment = new DetailFragment(this);
            fragment.setArguments(args);
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.movie_detail_container, fragment)
                    .commit();
        } else {
            Intent i = new Intent(this, DetailActivity.class);
            i.putExtras(intent.getExtras());
            startActivity(i);
        }

    }
}
