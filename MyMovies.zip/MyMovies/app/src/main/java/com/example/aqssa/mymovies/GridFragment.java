package com.example.aqssa.mymovies;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by Aqssa on 28/04/2016.
 */
public class GridFragment extends Fragment {




    private String[][] fullDataArray = new String[20][6];
    private String[][] dataFromDatabase;
    private GridView gridview;
    private GridImageAdapter mGridAdapter;
    private ArrayList<String> mGridData_from_API;
    private ArrayList<String> mGridData_from_Database = new ArrayList<>();
    private Menu optionsMenu;

    private final  String MOVIE_ID = "id";
    private final String MOVIE_POSTER="poster";
    private final  String MOVIE_TITLE= "title";
    private final  String MOVIE_OVERVIEW= "overview";
    private final  String MOVIE_RELEASE_DATE= "release_date";
    private final  String MOVIE_RATING= "rating";
    private final String MOVIE_SOURCE = "Source";

    private String mostPopularMovies;
    private String highestRatedMovie;
    private Context context;

    public static boolean mConnectivity;
    public static int Source;


    public GridFragment() {
    }

    public GridFragment(Context context){
        this.context=context;
    }

    public interface Callback {
        /**
         * DetailFragmentCallback for when an item has been selected.
         */
        public void onItemSelected(Intent intent);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);

    }









    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View rootView =inflater.inflate(R.layout.grid_fragment, container, false);

        gridview = (GridView) rootView.findViewById(R.id.gridview);
        mGridData_from_API = new ArrayList<>();
        mGridAdapter= new GridImageAdapter(getActivity(),mGridData_from_API);
        gridview.setAdapter(mGridAdapter);

        this.context=MainActivity.getContext();

        mostPopularMovies = "http://api.themoviedb.org/3/discover/movie?api_key="+MainActivity.API_KEY+"&sort_by=popularity.desc";
        highestRatedMovie = "http://api.themoviedb.org/3/discover/movie?api_key="+MainActivity.API_KEY+"&sort_by=vote_average.desc";


        return  rootView;
    }



    @Override
    public void onStart() {
        super.onStart();

        CheckConnection checkConnection=  new  CheckConnection();
        checkConnection.execute();

        gridview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                if (MainActivity.test) {
                    // In two-pane mode, show the detail view in this activity by
                    // adding or replacing the detail fragment using a
                    // fragment transaction.

                    if (Source == 1) {
                        Bundle args = new Bundle();
                        Intent i = new Intent();
                        args.putString(MOVIE_ID, fullDataArray[position][0]);
                        args.putString(MOVIE_POSTER, fullDataArray[position][1]);
                        args.putString(MOVIE_TITLE, fullDataArray[position][2]);
                        args.putString(MOVIE_OVERVIEW, fullDataArray[position][3]);
                        args.putString(MOVIE_RELEASE_DATE, fullDataArray[position][4]);
                        args.putString(MOVIE_RATING, fullDataArray[position][5]);
                        args.putInt(MOVIE_SOURCE, Source);

                        i.putExtras(args);
                        ((Callback) getActivity()).onItemSelected(i);

                    } else {
                        Intent i = new Intent();
                        Bundle args = new Bundle();
                        args.putString(MOVIE_ID, dataFromDatabase[position][0]);
                        args.putString(MOVIE_POSTER, dataFromDatabase[position][1]);
                        args.putString(MOVIE_TITLE, dataFromDatabase[position][2]);
                        args.putString(MOVIE_OVERVIEW, dataFromDatabase[position][3]);
                        args.putString(MOVIE_RELEASE_DATE, dataFromDatabase[position][4]);
                        args.putString(MOVIE_RATING, dataFromDatabase[position][5]);
                        args.putInt(MOVIE_SOURCE, Source);

                        i.putExtras(args);
                        ((Callback) getActivity()).onItemSelected(i);
                    }


                } else {

                    Intent intent = new Intent(getActivity(), DetailActivity.class);

                    if (Source == 1) {
                        Bundle bundle = new Bundle();
                        bundle.putString(MOVIE_ID, fullDataArray[position][0]);
                        bundle.putString(MOVIE_POSTER, fullDataArray[position][1]);
                        bundle.putString(MOVIE_TITLE, fullDataArray[position][2]);
                        bundle.putString(MOVIE_OVERVIEW, fullDataArray[position][3]);
                        bundle.putString(MOVIE_RELEASE_DATE, fullDataArray[position][4]);
                        bundle.putString(MOVIE_RATING, fullDataArray[position][5]);
                        bundle.putInt(MOVIE_SOURCE, Source);
                        intent.putExtras(bundle);
                    } else {
                        Bundle bundle = new Bundle();
                        bundle.putString(MOVIE_ID, dataFromDatabase[position][0]);
                        bundle.putString(MOVIE_POSTER, dataFromDatabase[position][1]);
                        bundle.putString(MOVIE_TITLE, dataFromDatabase[position][2]);
                        bundle.putString(MOVIE_OVERVIEW, dataFromDatabase[position][3]);
                        bundle.putString(MOVIE_RELEASE_DATE, dataFromDatabase[position][4]);
                        bundle.putString(MOVIE_RATING, dataFromDatabase[position][5]);
                        bundle.putInt(MOVIE_SOURCE, Source);
                        intent.putExtras(bundle);
                    }
                    startActivity(intent);
                }

            }
        });

    }

    private void updateMovieSorting() {

        String sort_mode = null;
        SharedPreferences preference = PreferenceManager.getDefaultSharedPreferences(getActivity());
        sort_mode = preference.getString(getString(R.string.pref_movie_sorting_key), getString(R.string.pref_most_popular));

        if (sort_mode.equals("favorites")) {

            Source = 2;
            Cursor c = getActivity().getContentResolver().query(FavoritesProvider.CONTENT_URI, null, null, null, "name");
            String[][] dataFromDB = new String[c.getCount()][6];
            if (!c.moveToFirst()) {
                Toast.makeText(getActivity(), " No Content Yet! Mark Movies As Favorites To Be Displayed Here", Toast.LENGTH_LONG).show();
            } else {
                mGridData_from_Database.clear();
                do {
                    dataFromDB[c.getPosition()][0] = c.getString(c.getColumnIndex(FavoritesProvider.MOVIE_ID_FROM_TMDB)); //id
                    dataFromDB[c.getPosition()][1] = c.getString(c.getColumnIndex(FavoritesProvider.MOVIE_POSTER)); //poster
                    dataFromDB[c.getPosition()][2] = c.getString(c.getColumnIndex(FavoritesProvider.MOVIE_NAME)); // title
                    dataFromDB[c.getPosition()][3] = c.getString(c.getColumnIndex(FavoritesProvider.MOVIE_OVERVIEW)); //overview
                    dataFromDB[c.getPosition()][4] = c.getString(c.getColumnIndex(FavoritesProvider.MOVIE_RELEASE_DATE)); // date
                    dataFromDB[c.getPosition()][5] = c.getString(c.getColumnIndex(FavoritesProvider.MOVIE_RATE)); // rating

                    mGridData_from_Database.add(dataFromDB[c.getPosition()][1]);

                } while (c.moveToNext());

                dataFromDatabase = new String[c.getCount()][6];

                for (int i = 0; i < c.getCount(); i++) {
                    for (int j = 0; j < 6; j++) {
                        dataFromDatabase[i][j] = dataFromDB[i][j];
                    }
                }

            }

            mGridAdapter.setGridDataFromDatabase(mGridData_from_Database, 2);


        } else

        if (sort_mode.equals("most_popular")) {

            Source = 1;

            if(mConnectivity)
            {
                new FetchMovie().execute(mostPopularMovies);
            }

        }

        else


        if (sort_mode.equals("highest_rated")) {
            Source = 1;
            if(mConnectivity)
            {new FetchMovie().execute(highestRatedMovie);}

        }

    }

    public void populateFavorites(){

        Source = 2;
        Cursor c = getActivity().getContentResolver().query(FavoritesProvider.CONTENT_URI, null, null, null, "name");
        String[][] dataFromDB = new String[c.getCount()][6];
        if (!c.moveToFirst()) {
            Toast.makeText(getActivity(), " No Content Yet! Mark Movies As Favorites ", Toast.LENGTH_LONG).show();
        } else {
            mGridData_from_Database.clear();
            do {
                dataFromDB[c.getPosition()][0] = c.getString(c.getColumnIndex(FavoritesProvider.MOVIE_ID_FROM_TMDB)); //id
                dataFromDB[c.getPosition()][1] = c.getString(c.getColumnIndex(FavoritesProvider.MOVIE_POSTER)); //poster
                dataFromDB[c.getPosition()][2] = c.getString(c.getColumnIndex(FavoritesProvider.MOVIE_NAME)); // title
                dataFromDB[c.getPosition()][3] = c.getString(c.getColumnIndex(FavoritesProvider.MOVIE_OVERVIEW)); //overview
                dataFromDB[c.getPosition()][4] = c.getString(c.getColumnIndex(FavoritesProvider.MOVIE_RELEASE_DATE)); // date
                dataFromDB[c.getPosition()][5] = c.getString(c.getColumnIndex(FavoritesProvider.MOVIE_RATE)); // rating

                mGridData_from_Database.add(dataFromDB[c.getPosition()][1]);

            } while (c.moveToNext());

            dataFromDatabase = new String[c.getCount()][6];
            for (int i = 0; i < c.getCount(); i++) {
                for (int j = 0; j < 6; j++) {
                    dataFromDatabase[i][j] = dataFromDB[i][j];
                }
            }
        }

        mGridAdapter.setGridDataFromDatabase(mGridData_from_Database, 2);
        Toast.makeText(getActivity(), "Favorites ... Connection issue!", Toast.LENGTH_LONG).show();

    }


    public class FetchMovie extends AsyncTask<String, Void, String[]> {

        final String LOG_TAG = FetchMovie.class.getSimpleName();

        @Override
        protected String[] doInBackground(String... params) {


            HttpURLConnection urlConnection = null;
            BufferedReader reader = null;
            String movieDBJsonStr = null;

            try {

                URL url = new URL(params[0]);

                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.connect();

                InputStream inputStream = urlConnection.getInputStream();
                StringBuffer buffer = new StringBuffer();

                if (inputStream == null) {
                    return null;
                }

                reader = new BufferedReader(new InputStreamReader(inputStream));

                String line;
                while ((line = reader.readLine()) != null) {
                    buffer.append(line + "\n");
                }

                if (buffer.length() == 0) {
                    return null;
                }


                movieDBJsonStr = buffer.toString();



            } catch (IOException e) {
                Log.e(LOG_TAG, "Error ", e);
                return null;
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (final IOException e) {
                        Log.e(LOG_TAG, "Error closing ", e);
                    }
                }
            }

            try {
                return getMoviesDataFromJsonStr(movieDBJsonStr);
            } catch (JSONException e) {
                e.printStackTrace();
            }

            return null;
        }/////// doInBackground


        private String[] getMoviesDataFromJsonStr(String jsonStr) throws JSONException {

            final String RESULTS = "results";
            final String POSTER = "poster_path";
            final String POSTER_BASE_URL = "http://image.tmdb.org/t/p/w185";
            final String TITLE = "original_title";
            final String OVERVIEW = "overview";
            final String RELEASE_DATE = "release_date";
            final String RATING = "vote_average";
            final String ID = "id";


            String ImageURL;
            String OriginalTitle;
            String OverView;
            String ReleaseDate;
            String Rating;
            String Movie_ID;

            JSONObject MovieJosnObject = new JSONObject(jsonStr);
            JSONArray MovieArray = MovieJosnObject.getJSONArray(RESULTS);

            String[] ImageUrlArray = new String[MovieArray.length()];


            for (int i = 0; i < MovieArray.length(); i++) {

                JSONObject ArrayElement = MovieArray.getJSONObject(i);
                ImageURL = POSTER_BASE_URL + ArrayElement.getString(POSTER);
                OriginalTitle = ArrayElement.getString(TITLE);
                OverView = ArrayElement.getString(OVERVIEW);
                ReleaseDate = ArrayElement.getString(RELEASE_DATE);
                Rating = ArrayElement.getString(RATING);
                Movie_ID = ArrayElement.getString(ID);

                fullDataArray[i][0] = Movie_ID;
                fullDataArray[i][1] = ImageURL;
                fullDataArray[i][2] = OriginalTitle;
                fullDataArray[i][3] = OverView;
                fullDataArray[i][4] = ReleaseDate;
                fullDataArray[i][5] = Rating;


            }

            for (int i = 0; i < MovieArray.length(); i++) {
                ImageUrlArray[i] = fullDataArray[i][1];
            }

            return ImageUrlArray;
        }


        @Override
        protected void onPostExecute(String[] result) {
            super.onPostExecute(result);

            mGridData_from_API.clear();
            for (int i = 0; i < result.length; i++) {
                mGridData_from_API.add(result[i]);
            }

            mGridAdapter.setGridData(mGridData_from_API, 1);

        }


    }

    public class CheckConnection extends AsyncTask<Void,Void,Boolean>{

        @Override
        protected Boolean doInBackground(Void... params) {
            ConnectivityManager connectivityManager = (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo netInfo = connectivityManager.getActiveNetworkInfo();
            if (netInfo != null && netInfo.isConnected()) {
                try { // more accurate internet check
                    URL url = new URL("http://www.google.com/");
                    HttpURLConnection urlc = (HttpURLConnection)url.openConnection();
                    urlc.setRequestProperty("User-Agent", "test");
                    urlc.setRequestProperty("Connection", "close");
                    urlc.setConnectTimeout(1000);
                    urlc.connect();
                    if (urlc.getResponseCode() == 200) {
                        mConnectivity =true;
                    } else {
                        mConnectivity =false;
                    }
                } catch (IOException e) {
                    Log.i("warning", "checking internet connection", e);
                }
            }else {
                mConnectivity=false;
            }

            return mConnectivity;
        }

        @Override
        protected void onPostExecute(Boolean aBoolean) {
            super.onPostExecute(aBoolean);

            if(aBoolean){
                updateMovieSorting();
            }else {
                populateFavorites();
            }

        }


    }

}
